# 小说写作工具包

这是一个可以单独分享给其他人使用的小说写作工具包，包含两部分：

1. `skill/`
   一个可安装到 Codex 的小说写作技能，支持构思、大纲、续写、平台改稿、长期记忆联动、分批审核。
2. `memory-toolkit/`
   一个独立可运行的长期记忆工具，适合沉淀人物、设定、伏笔、剧情事实和章节摘要。

## 适合谁

- 用 Codex 写小说、做网文策划的人
- 想把长篇连载设定沉淀下来，避免前后打架的人
- 想把“写作技能 + 长期记忆工具”一并发给团队成员的人

## 目录说明

```text
shareable-novel-toolkit/
  README.md
  skill/
  memory-toolkit/
  scripts/
```

## 快速开始

### 1. 安装小说技能

把 `skill/` 目录复制到对方的 Codex 技能目录中，目录名建议保留为 `qimao-novel-writing`。

如果对方使用的是本机技能目录，通常放到：

```text
~/.codex/skills/qimao-novel-writing
```

### 2. 安装长期记忆工具

进入 `memory-toolkit/` 后执行：

```bash
python3 -m venv .venv
source .venv/bin/activate
python3 -m pip install -U pip
python3 -m pip install -e .
```

安装完成后，就可以直接使用：

```bash
novel-memory init
novel-memory add --kind character --title "林夜" --content "男主，外门弟子，隐藏底牌极深。"
novel-memory search --query "林夜 隐藏底牌"
```

### 3. 可选：自定义记忆数据目录

如果不想把数据放在工具目录自带的 `data/` 下，可以提前设置：

```bash
export NOVEL_MEMORY_DATA_DIR="/你的数据目录"
```

也可以单独指定存储文件：

```bash
export NOVEL_MEMORY_STORE_PATH="/你的数据目录/memories.json"
```

## 推荐使用方式

### 单人作者

- 用技能做构思、章纲、续写、审稿
- 用长期记忆工具沉淀人物、设定、剧情事实、伏笔

### 团队协作

- 所有人使用同一套技能规则
- 主笔或策划维护长期记忆库
- 审稿时按技能里的分批审核机制走

## 技能亮点

- 支持从零立项、续写已有稿、审稿诊断、平台改稿、卡文急救
- 支持七猫、番茄、起点三套平台适配思路
- 支持长期记忆联动
- 支持单章、小批次、整卷三层审核

## 长期记忆工具亮点

- 支持人物、世界观、剧情事实、伏笔、关系、章节摘要、硬约束
- 支持从章节自动提炼记忆
- 支持后续接入 Mem0 和 LangGraph
- 支持通过环境变量切换数据目录

## 一键脚本

如果对方只是想快速试用长期记忆工具，可以在 `scripts/` 里直接运行安装脚本。
