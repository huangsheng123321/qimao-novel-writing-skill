# 长期记忆接入

## 适用场景

- 用户在写长篇连载，不止一章。
- 用户已经有旧稿、旧设定、旧人物关系，需要持续续写。
- 用户明确提到“长期记忆”“设定别打架”“帮我记住前文”。

## 优先策略

如果当前工作区已经有 `novel_memory/` 项目，就优先复用它，不要再平行维护一套口头记忆规则。

当前项目路径：

- 总说明：`/Users/huangsheng/Documents/小说写作/README.md`
- 命令入口：`/Users/huangsheng/Documents/小说写作/novel_memory/cli.py`

## 使用原则

1. 稳定设定写成结构化长期记忆。
2. 新章节先提炼摘要和关键事实，再写入记忆。
3. 写新章前先召回相关人物、设定、伏笔、最近剧情。
4. 发现冲突时，先指出冲突点，再决定改前文还是改新稿。

## 这套项目当前能存什么

- `character`：人物
- `worldbuilding`：世界观
- `plot_fact`：剧情事实
- `foreshadow`：伏笔
- `writing_preference`：写作偏好
- `relationship`：人物关系
- `chapter_summary`：章节摘要
- `constraint`：硬约束

## 推荐工作流

### 1. 首次接手一本书

- 先读用户现有大纲、人物设定、样章。
- 提炼故事圣经、人物表、时间线、伏笔回收表、设定禁忌表。
- 能结构化的内容，尽量写入 `novel_memory`。

### 2. 每次续写前

- 先搜索主角、当前副本、当前冲突、最近章节相关记忆。
- 重点看 4 类：人物、剧情事实、伏笔、硬约束。
- 召回后再续写，不要裸写。

### 3. 每次续写后

- 至少补 1 条章节摘要。
- 把这一章新产生的关键事实、关系变化、伏笔、设定补进记忆。
- 如果人物口头禅、动机、立场发生明确变化，也要更新。

## 常用操作

初始化：

```bash
python3 -m novel_memory.cli init
```

添加一条记忆：

```bash
python3 -m novel_memory.cli add --kind character --title "角色名" --content "核心设定" --tags 标签1 标签2
```

按关键词检索：

```bash
python3 -m novel_memory.cli search --query "主角 当前副本 伏笔"
```

导入新章节并自动提炼：

```bash
python3 -m novel_memory.cli ingest-chapter --file 章节文件路径 --chapter-title "章节名"
```

## 什么时候可以只做轻量维护

如果用户只是临时要一个脑洞、一个开头、一个单章试写，不一定要启动完整长期记忆流程。

如果任务已经进入“持续写这本书”的状态，就应主动建议接入这套记忆工具。
