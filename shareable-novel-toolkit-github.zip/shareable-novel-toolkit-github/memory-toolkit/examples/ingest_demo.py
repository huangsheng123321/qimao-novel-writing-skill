from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from novel_memory.chapter_ingest import ingest_chapter_file
from novel_memory.memory_service import MemoryService


def main() -> None:
    file_path = sys.argv[1] if len(sys.argv) > 1 else "examples/sample_chapter.txt"
    chapter_title = sys.argv[2] if len(sys.argv) > 2 else "示例章节"
    result = ingest_chapter_file(file_path, chapter_title=chapter_title, service=MemoryService())
    print(f"章节摘要: {result.summary}")
    print(f"新增记忆数: {len(result.memories)}")
    for item in result.memories:
        print(f"{item.kind} | {item.title} | {item.content}")


if __name__ == "__main__":
    main()

