from __future__ import annotations

import os
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from novel_memory.mem0_adapter import Mem0Adapter
from novel_memory.memory_service import MemoryService


def main() -> None:
    user_id = os.environ.get("NOVEL_MEMORY_USER_ID", "default-author")
    service = MemoryService()
    adapter = Mem0Adapter(user_id=user_id)

    count = 0
    for memory in service.list_memories():
        adapter.add(memory)
        count += 1
    print(f"Synced {count} memories to Mem0 for user_id={user_id}.")


if __name__ == "__main__":
    main()
