from __future__ import annotations

import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from novel_memory.langgraph_flow import example_langgraph_state
from novel_memory.memory_service import MemoryService


def main() -> None:
    query = sys.argv[1] if len(sys.argv) > 1 else "下一章写作前需要召回的关键信息"
    service = MemoryService()
    state = example_langgraph_state(query, service)
    print(json.dumps(state, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
