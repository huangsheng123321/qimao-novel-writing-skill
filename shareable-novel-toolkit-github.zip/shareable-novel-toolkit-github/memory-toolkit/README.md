# 小说写作长期记忆

这是一个面向小说创作的长期记忆骨架。

它采用两层设计：

- `LangGraph` 负责后续可扩展的工作流编排。
- `Mem0` 负责专业长期记忆接入。

为了保证你现在就能开始使用，项目还内置了一套本地 JSON 存储。即使暂时没有安装任何外部依赖，你也可以先把人物、设定、伏笔、章节事实沉淀下来。

## 适合记录的内容

- 人物设定：身份、动机、口头禅、关系网、成长线
- 世界观：势力、地点、规则、境界、系统
- 剧情事实：章节发生了什么、谁知道什么、谁误会了什么
- 伏笔与回收：埋点位置、触发条件、计划回收章节
- 写作偏好：语言风格、禁忌词、节奏要求、平台侧重点

## 目录结构

```text
novel_memory/
  cli.py
  config.py
  models.py
  store.py
  memory_service.py
  mem0_adapter.py
  langgraph_flow.py
data/
  memories.json
examples/
  seed_memories.json
  mem0_sync.py
  langgraph_demo.py
  sample_chapter.txt
  ingest_demo.py
```

## 先用起来

### 1. 初始化记忆文件

```bash
python3 -m novel_memory.cli init
```

### 2. 写入一条长期记忆

```bash
python3 -m novel_memory.cli add \
  --kind character \
  --title "林夜" \
  --content "男主，表面是外门弟子，实际拥有吞天古碑。说话少，出手狠。" \
  --tags 男主 修仙 隐藏身份
```

### 3. 检索记忆

```bash
python3 -m novel_memory.cli search --query "隐藏身份 男主"
```

### 4. 查看某一类记忆

```bash
python3 -m novel_memory.cli list --kind foreshadow
```

## 记忆类别

- `character`：人物
- `worldbuilding`：世界观
- `plot_fact`：剧情事实
- `foreshadow`：伏笔
- `writing_preference`：写作偏好
- `relationship`：人物关系
- `chapter_summary`：章节摘要
- `constraint`：硬约束

## 和 Mem0 / LangGraph 的关系

### Mem0

`novel_memory/mem0_adapter.py` 提供了接入点。等你安装好 `mem0ai` 后，可以把本地结构化记忆同步到 Mem0，或者直接让新记忆同时写入 Mem0。

### LangGraph

`novel_memory/langgraph_flow.py` 给了一个“写作前召回记忆 -> 生成上下文 -> 写入新记忆”的流程骨架。等你准备接模型时，只需要把模型调用填进去即可。

## 可选安装

如果你准备接专业记忆层，可以安装依赖：

```bash
python3 -m pip install -r requirements.txt
```

如果你只想先用本地记忆，不装也可以。

## 示例

### 导入示例数据

```bash
python3 -m novel_memory.cli import --file examples/seed_memories.json
```

### 生成写作前记忆上下文

```bash
python3 examples/langgraph_demo.py "男主进入遗迹前需要注意的伏笔和设定"
```

### 同步到 Mem0

先设置环境变量：

```bash
export NOVEL_MEMORY_USER_ID="author-001"
```

然后执行：

```bash
./.venv/bin/python examples/mem0_sync.py
```

项目会自动把 `Mem0` 的本地配置目录放到 `data/.mem0/`，不会写到你的用户主目录。

### 把新章节自动入库

```bash
./.venv/bin/python -m novel_memory.cli ingest-chapter \
  --file examples/sample_chapter.txt \
  --chapter-title "第12章 黑石谷异动"
```

如果你也想同步到 `Mem0`：

```bash
./.venv/bin/python -m novel_memory.cli ingest-chapter \
  --file examples/sample_chapter.txt \
  --chapter-title "第12章 黑石谷异动" \
  --sync-mem0
```

也可以直接跑示例脚本：

```bash
./.venv/bin/python examples/ingest_demo.py examples/sample_chapter.txt "第12章 黑石谷异动"
```

## 建议的使用方式

真正专业、也最稳的做法不是“把所有聊天都丢进去”，而是分层：

1. 稳定信息写成结构化长期记忆。
2. 章节内容写成摘要型记忆。
3. 临时对话只保留有价值的信息。
4. 每次写新章前先召回相关人物、设定、伏笔、最近剧情。

## 当前自动提取能力

现在这套工具已经能从新章节里自动沉淀：

- `chapter_summary`：这一章发生了什么
- `plot_fact`：明确发生的关键剧情事实
- `foreshadow`：疑点、异动、秘密、后续可回收线索
- `worldbuilding`：宗门、秘境、阵法、境界、规则等设定
- `relationship`：师门、亲属、盟友、仇敌等关系线索

这版先用本地规则提取，优点是马上能跑、稳定、零额外模型依赖。后面如果你想要更强的抽取精度，我可以继续把它升级成 “本地规则 + 大模型抽取 + 冲突检查” 的组合版。

## 下一步可做

- 接入 `Mem0` 做更强的长期记忆抽取
- 接入 `LangGraph` 做自动化写作流程
- 增加 SQLite 或向量检索
- 加一个“设定冲突检查器”
