from __future__ import annotations

from typing import Any

from .memory_service import MemoryService


def build_writer_context(
    service: MemoryService,
    *,
    query: str,
    top_k: int = 8,
) -> dict[str, Any]:
    """Prepare a compact memory bundle before planning or writing a chapter."""
    memories = service.search_memories(query)[:top_k]
    return {
        "query": query,
        "memories": [item.to_dict() for item in memories],
        "summary": "\n\n".join(
            f"- [{item.kind}] {item.title}: {item.content}" for item in memories
        ),
    }


def example_langgraph_state(query: str, service: MemoryService) -> dict[str, Any]:
    """A simple state shape you can feed into a future LangGraph workflow."""
    context = build_writer_context(service, query=query)
    return {
        "user_goal": query,
        "memory_context": context,
        "draft": "",
        "new_memories": [],
    }


def build_langgraph_example(service: MemoryService) -> Any:
    """Return a minimal LangGraph workflow when langgraph is available."""
    try:
        from langgraph.graph import END, START, StateGraph
    except ImportError as exc:
        raise RuntimeError(
            "langgraph is not installed. Install dependencies first, then retry."
        ) from exc

    def recall_node(state: dict[str, Any]) -> dict[str, Any]:
        query = state["user_goal"]
        state["memory_context"] = build_writer_context(service, query=query)
        return state

    def draft_node(state: dict[str, Any]) -> dict[str, Any]:
        summary = state["memory_context"]["summary"]
        state["draft"] = (
            "这里接入你的模型生成逻辑。\n\n"
            f"当前召回记忆如下：\n{summary}"
        )
        return state

    graph = StateGraph(dict)
    graph.add_node("recall_memory", recall_node)
    graph.add_node("draft_scene", draft_node)
    graph.add_edge(START, "recall_memory")
    graph.add_edge("recall_memory", "draft_scene")
    graph.add_edge("draft_scene", END)
    return graph.compile()
