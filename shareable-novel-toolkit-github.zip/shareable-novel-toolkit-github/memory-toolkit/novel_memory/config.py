from __future__ import annotations

import os
from pathlib import Path


ROOT_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = Path(os.environ.get("NOVEL_MEMORY_DATA_DIR", ROOT_DIR / "data")).expanduser()
DEFAULT_STORE_PATH = Path(
    os.environ.get("NOVEL_MEMORY_STORE_PATH", DATA_DIR / "memories.json")
).expanduser()
MEM0_DIR = Path(os.environ.get("NOVEL_MEMORY_MEM0_DIR", DATA_DIR / ".mem0")).expanduser()
