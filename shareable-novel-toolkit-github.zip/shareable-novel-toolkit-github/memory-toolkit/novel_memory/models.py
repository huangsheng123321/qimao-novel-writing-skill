from __future__ import annotations

from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from typing import Any
from uuid import uuid4


MEMORY_KINDS = {
    "character",
    "worldbuilding",
    "plot_fact",
    "foreshadow",
    "writing_preference",
    "relationship",
    "chapter_summary",
    "constraint",
}


def utc_now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


@dataclass
class MemoryItem:
    kind: str
    title: str
    content: str
    tags: list[str] = field(default_factory=list)
    metadata: dict[str, Any] = field(default_factory=dict)
    source: str = "manual"
    importance: int = 3
    memory_id: str = field(default_factory=lambda: str(uuid4()))
    created_at: str = field(default_factory=utc_now_iso)
    updated_at: str = field(default_factory=utc_now_iso)

    def validate(self) -> None:
        if self.kind not in MEMORY_KINDS:
            valid = ", ".join(sorted(MEMORY_KINDS))
            raise ValueError(f"Unsupported kind: {self.kind}. Use one of: {valid}")
        if not self.title.strip():
            raise ValueError("title cannot be empty")
        if not self.content.strip():
            raise ValueError("content cannot be empty")
        if not 1 <= self.importance <= 5:
            raise ValueError("importance must be between 1 and 5")

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, payload: dict[str, Any]) -> "MemoryItem":
        return cls(**payload)

