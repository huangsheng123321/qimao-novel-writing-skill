from __future__ import annotations

import os
from typing import Any

from .config import MEM0_DIR
from .models import MemoryItem


class Mem0Adapter:
    """Optional bridge for syncing structured novel memories into Mem0."""

    def __init__(self, user_id: str) -> None:
        self.user_id = user_id
        self._client: Any | None = None

    def _get_client(self) -> Any:
        if self._client is not None:
            return self._client
        MEM0_DIR.mkdir(parents=True, exist_ok=True)
        os.environ.setdefault("MEM0_DIR", str(MEM0_DIR))
        try:
            from mem0 import Memory
        except ImportError as exc:
            raise RuntimeError(
                "mem0 is not installed. Install it first, then retry."
            ) from exc
        self._client = Memory()
        return self._client

    def add(self, memory: MemoryItem) -> Any:
        client = self._get_client()
        content = (
            f"[{memory.kind}] {memory.title}\n"
            f"{memory.content}\n"
            f"tags: {', '.join(memory.tags)}"
        )
        metadata = {
            "kind": memory.kind,
            "title": memory.title,
            "importance": memory.importance,
            **memory.metadata,
        }
        return client.add(content, user_id=self.user_id, metadata=metadata)
