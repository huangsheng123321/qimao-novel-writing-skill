from __future__ import annotations

import json
from pathlib import Path

from .config import DEFAULT_STORE_PATH
from .models import MemoryItem


class JsonMemoryStore:
    def __init__(self, path: Path | None = None) -> None:
        self.path = path or DEFAULT_STORE_PATH

    def init_store(self) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        if not self.path.exists():
            self.path.write_text("[]\n", encoding="utf-8")

    def load_all(self) -> list[MemoryItem]:
        self.init_store()
        payload = json.loads(self.path.read_text(encoding="utf-8"))
        return [MemoryItem.from_dict(item) for item in payload]

    def save_all(self, memories: list[MemoryItem]) -> None:
        self.init_store()
        serializable = [item.to_dict() for item in memories]
        text = json.dumps(serializable, ensure_ascii=False, indent=2)
        self.path.write_text(text + "\n", encoding="utf-8")

