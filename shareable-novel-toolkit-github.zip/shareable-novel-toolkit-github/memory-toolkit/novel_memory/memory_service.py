from __future__ import annotations

from dataclasses import replace
from datetime import datetime, timezone

from .models import MemoryItem
from .store import JsonMemoryStore


class MemoryService:
    def __init__(self, store: JsonMemoryStore | None = None) -> None:
        self.store = store or JsonMemoryStore()

    def init_store(self) -> None:
        self.store.init_store()

    def add_memory(self, memory: MemoryItem) -> MemoryItem:
        memory.validate()
        memories = self.store.load_all()
        memories.append(memory)
        self.store.save_all(memories)
        return memory

    def list_memories(self, kind: str | None = None) -> list[MemoryItem]:
        memories = self.store.load_all()
        if kind is None:
            return memories
        return [item for item in memories if item.kind == kind]

    def search_memories(self, query: str, kind: str | None = None) -> list[MemoryItem]:
        query_terms = [term for term in query.lower().split() if term]
        results: list[tuple[int, MemoryItem]] = []
        for item in self.list_memories(kind=kind):
            haystack = " ".join(
                [
                    item.title,
                    item.content,
                    " ".join(item.tags),
                    " ".join(f"{key}:{value}" for key, value in item.metadata.items()),
                ]
            ).lower()
            score = sum(term in haystack for term in query_terms)
            if score:
                results.append((score + item.importance, item))
        results.sort(key=lambda pair: pair[0], reverse=True)
        return [item for _, item in results]

    def update_memory(
        self,
        memory_id: str,
        *,
        title: str | None = None,
        content: str | None = None,
        tags: list[str] | None = None,
        importance: int | None = None,
    ) -> MemoryItem:
        memories = self.store.load_all()
        for index, item in enumerate(memories):
            if item.memory_id != memory_id:
                continue
            updated = replace(
                item,
                title=title if title is not None else item.title,
                content=content if content is not None else item.content,
                tags=tags if tags is not None else item.tags,
                importance=importance if importance is not None else item.importance,
                updated_at=datetime.now(timezone.utc).isoformat(),
            )
            updated.validate()
            memories[index] = updated
            self.store.save_all(memories)
            return updated
        raise KeyError(f"Memory not found: {memory_id}")

