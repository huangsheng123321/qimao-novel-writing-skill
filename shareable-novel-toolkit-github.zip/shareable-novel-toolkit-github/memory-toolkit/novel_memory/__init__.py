"""Novel writing long-term memory toolkit."""

