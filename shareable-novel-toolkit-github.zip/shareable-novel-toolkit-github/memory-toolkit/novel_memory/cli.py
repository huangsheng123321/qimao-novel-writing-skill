from __future__ import annotations

import argparse
import json
import os
from pathlib import Path

from .chapter_ingest import ingest_chapter_file
from .memory_service import MemoryService
from .models import MEMORY_KINDS, MemoryItem


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Novel long-term memory CLI")
    subparsers = parser.add_subparsers(dest="command", required=True)

    subparsers.add_parser("init", help="Initialize the memory store")

    add_parser = subparsers.add_parser("add", help="Add a memory item")
    add_parser.add_argument("--kind", required=True, choices=sorted(MEMORY_KINDS))
    add_parser.add_argument("--title", required=True)
    add_parser.add_argument("--content", required=True)
    add_parser.add_argument("--tags", nargs="*", default=[])
    add_parser.add_argument("--importance", type=int, default=3)
    add_parser.add_argument("--source", default="manual")
    add_parser.add_argument("--metadata", default="{}")

    list_parser = subparsers.add_parser("list", help="List memory items")
    list_parser.add_argument("--kind", choices=sorted(MEMORY_KINDS))

    search_parser = subparsers.add_parser("search", help="Search memory items")
    search_parser.add_argument("--query", required=True)
    search_parser.add_argument("--kind", choices=sorted(MEMORY_KINDS))

    update_parser = subparsers.add_parser("update", help="Update a memory item")
    update_parser.add_argument("--id", required=True)
    update_parser.add_argument("--title")
    update_parser.add_argument("--content")
    update_parser.add_argument("--tags", nargs="*")
    update_parser.add_argument("--importance", type=int)

    import_parser = subparsers.add_parser("import", help="Import memories from JSON")
    import_parser.add_argument("--file", required=True)

    ingest_parser = subparsers.add_parser("ingest-chapter", help="Ingest a chapter file into memories")
    ingest_parser.add_argument("--file", required=True)
    ingest_parser.add_argument("--chapter-title")
    ingest_parser.add_argument("--sync-mem0", action="store_true")
    ingest_parser.add_argument("--mem0-user-id", default=os.environ.get("NOVEL_MEMORY_USER_ID", "default-author"))

    return parser


def print_memories(memories: list[MemoryItem]) -> None:
    for item in memories:
        print(f"{item.memory_id} | {item.kind} | {item.title} | tags={','.join(item.tags)}")
        print(f"  {item.content}")


def handle_import(service: MemoryService, file_path: str) -> None:
    payload = json.loads(Path(file_path).read_text(encoding="utf-8"))
    for row in payload:
        memory = MemoryItem.from_dict(row)
        service.add_memory(memory)
    print(f"Imported {len(payload)} memories.")


def print_ingest_result(summary: str, memories: list[MemoryItem]) -> None:
    print(f"章节摘要: {summary}")
    print(f"新增长期记忆: {len(memories)}")
    for item in memories:
        print(f"- {item.kind} | {item.title} | {item.content}")


def main() -> None:
    parser = build_parser()
    args = parser.parse_args()
    service = MemoryService()

    if args.command == "init":
        service.init_store()
        print("Memory store initialized.")
        return

    if args.command == "add":
        metadata = json.loads(args.metadata)
        memory = MemoryItem(
            kind=args.kind,
            title=args.title,
            content=args.content,
            tags=args.tags,
            importance=args.importance,
            source=args.source,
            metadata=metadata,
        )
        saved = service.add_memory(memory)
        print(f"Saved memory: {saved.memory_id}")
        return

    if args.command == "list":
        print_memories(service.list_memories(kind=args.kind))
        return

    if args.command == "search":
        print_memories(service.search_memories(query=args.query, kind=args.kind))
        return

    if args.command == "update":
        updated = service.update_memory(
            args.id,
            title=args.title,
            content=args.content,
            tags=args.tags,
            importance=args.importance,
        )
        print(f"Updated memory: {updated.memory_id}")
        return

    if args.command == "import":
        handle_import(service, args.file)
        return

    if args.command == "ingest-chapter":
        result = ingest_chapter_file(
            args.file,
            chapter_title=args.chapter_title,
            service=service,
            sync_mem0=args.sync_mem0,
            mem0_user_id=args.mem0_user_id,
        )
        print_ingest_result(result.summary, result.memories)
        return


if __name__ == "__main__":
    main()
