from __future__ import annotations

import re
from dataclasses import dataclass
from pathlib import Path

from .mem0_adapter import Mem0Adapter
from .memory_service import MemoryService
from .models import MemoryItem


PLOT_HINTS = (
    "发现",
    "得知",
    "看见",
    "听见",
    "决定",
    "答应",
    "拒绝",
    "进入",
    "离开",
    "击败",
    "救下",
    "突破",
    "怀疑",
    "质问",
    "暴露",
    "隐藏",
    "夺下",
    "开启",
    "拿到",
    "遇到",
)

FORESHADOW_HINTS = (
    "预感",
    "隐约",
    "异动",
    "迟早",
    "总觉得",
    "秘密",
    "线索",
    "不对劲",
    "迟疑",
    "震动",
    "将会",
    "注定",
    "也许",
)

WORLD_HINTS = (
    "宗门",
    "世家",
    "王朝",
    "秘境",
    "禁地",
    "灵气",
    "阵法",
    "法则",
    "境界",
    "血脉",
    "功法",
    "规则",
    "城",
    "殿",
    "峰",
    "阁",
)

RELATION_HINTS = (
    "师父",
    "师兄",
    "师姐",
    "父亲",
    "母亲",
    "兄长",
    "妹妹",
    "未婚妻",
    "同门",
    "盟友",
    "仇人",
)


@dataclass
class IngestResult:
    memories: list[MemoryItem]
    summary: str


def split_paragraphs(text: str) -> list[str]:
    parts = [part.strip() for part in re.split(r"\n\s*\n+", text) if part.strip()]
    if parts:
        return parts
    return [line.strip() for line in text.splitlines() if line.strip()]


def split_sentences(text: str) -> list[str]:
    segments = re.split(r"(?<=[。！？!?；;])", text)
    return [segment.strip() for segment in segments if segment.strip()]


def compact_text(text: str, limit: int = 120) -> str:
    text = re.sub(r"\s+", " ", text).strip()
    return text if len(text) <= limit else text[: limit - 1] + "…"


def pick_summary(paragraphs: list[str], max_parts: int = 3) -> str:
    selected = [compact_text(part, limit=80) for part in paragraphs[:max_parts]]
    return " ".join(selected)


def detect_tags(text: str) -> list[str]:
    tags: list[str] = []
    if any(word in text for word in WORLD_HINTS):
        tags.append("设定")
    if any(word in text for word in FORESHADOW_HINTS):
        tags.append("伏笔")
    if any(word in text for word in RELATION_HINTS):
        tags.append("关系")
    if "男主" in text:
        tags.append("男主")
    if "女主" in text:
        tags.append("女主")
    return tags


def extract_named_terms(text: str, limit: int = 6) -> list[str]:
    candidates = re.findall(r"[\u4e00-\u9fff]{2,6}", text)
    blocked = {
        "自己",
        "什么",
        "时候",
        "那里",
        "这里",
        "如果",
        "因为",
        "虽然",
        "于是",
        "他们",
        "我们",
        "不是",
        "没有",
        "这个",
        "那个",
    }
    results: list[str] = []
    for item in candidates:
        if item in blocked:
            continue
        if item in results:
            continue
        results.append(item)
        if len(results) >= limit:
            break
    return results


def build_memory(
    *,
    kind: str,
    title: str,
    content: str,
    chapter_title: str,
    importance: int,
    tags: list[str] | None = None,
    metadata: dict[str, str] | None = None,
) -> MemoryItem:
    return MemoryItem(
        kind=kind,
        title=title,
        content=content,
        tags=(tags or []) + [chapter_title],
        importance=importance,
        source="chapter_ingest",
        metadata={"chapter_title": chapter_title, **(metadata or {})},
    )


def extract_plot_memories(chapter_title: str, sentences: list[str]) -> list[MemoryItem]:
    items: list[MemoryItem] = []
    for sentence in sentences:
        if not any(hint in sentence for hint in PLOT_HINTS):
            continue
        title = compact_text(sentence, limit=24)
        tags = detect_tags(sentence) + extract_named_terms(sentence, limit=3)
        items.append(
            build_memory(
                kind="plot_fact",
                title=f"{chapter_title}剧情",
                content=compact_text(sentence, limit=150),
                chapter_title=chapter_title,
                importance=4,
                tags=tags,
            )
        )
        if len(items) >= 5:
            break
    return items


def extract_foreshadow_memories(chapter_title: str, sentences: list[str]) -> list[MemoryItem]:
    items: list[MemoryItem] = []
    for sentence in sentences:
        if not any(hint in sentence for hint in FORESHADOW_HINTS):
            continue
        items.append(
            build_memory(
                kind="foreshadow",
                title=f"{chapter_title}伏笔",
                content=compact_text(sentence, limit=150),
                chapter_title=chapter_title,
                importance=4,
                tags=["自动提取", "伏笔"] + extract_named_terms(sentence, limit=3),
            )
        )
        if len(items) >= 3:
            break
    return items


def extract_world_memories(chapter_title: str, sentences: list[str]) -> list[MemoryItem]:
    items: list[MemoryItem] = []
    for sentence in sentences:
        world_hits = [hint for hint in WORLD_HINTS if hint in sentence]
        if not world_hits:
            continue
        if any(hint in sentence for hint in ("抢", "冷笑", "看见", "质问", "冲了进去", "外门废物")):
            continue
        if world_hits == ["秘境"] and "机缘" in sentence:
            continue
        items.append(
            build_memory(
                kind="worldbuilding",
                title=f"{chapter_title}设定",
                content=compact_text(sentence, limit=150),
                chapter_title=chapter_title,
                importance=3,
                tags=["自动提取", "设定"] + extract_named_terms(sentence, limit=3),
            )
        )
        if len(items) >= 3:
            break
    return items


def extract_relationship_memories(chapter_title: str, sentences: list[str]) -> list[MemoryItem]:
    items: list[MemoryItem] = []
    for sentence in sentences:
        if not any(hint in sentence for hint in RELATION_HINTS):
            continue
        items.append(
            build_memory(
                kind="relationship",
                title=f"{chapter_title}关系",
                content=compact_text(sentence, limit=150),
                chapter_title=chapter_title,
                importance=3,
                tags=["自动提取", "关系"] + extract_named_terms(sentence, limit=3),
            )
        )
        if len(items) >= 3:
            break
    return items


def ingest_chapter_text(
    text: str,
    *,
    chapter_title: str,
    service: MemoryService,
    sync_mem0: bool = False,
    mem0_user_id: str = "default-author",
) -> IngestResult:
    paragraphs = split_paragraphs(text)
    sentences = split_sentences(text)
    summary = pick_summary(paragraphs)

    memories: list[MemoryItem] = [
        build_memory(
            kind="chapter_summary",
            title=chapter_title,
            content=summary,
            chapter_title=chapter_title,
            importance=5,
            tags=["自动提取", "章节摘要"] + detect_tags(text),
            metadata={"paragraph_count": str(len(paragraphs)), "sentence_count": str(len(sentences))},
        )
    ]
    memories.extend(extract_plot_memories(chapter_title, sentences))
    memories.extend(extract_foreshadow_memories(chapter_title, sentences))
    memories.extend(extract_world_memories(chapter_title, sentences))
    memories.extend(extract_relationship_memories(chapter_title, sentences))

    for memory in memories:
        service.add_memory(memory)

    if sync_mem0:
        adapter = Mem0Adapter(user_id=mem0_user_id)
        for memory in memories:
            adapter.add(memory)

    return IngestResult(memories=memories, summary=summary)


def ingest_chapter_file(
    file_path: str | Path,
    *,
    chapter_title: str | None = None,
    service: MemoryService,
    sync_mem0: bool = False,
    mem0_user_id: str = "default-author",
) -> IngestResult:
    path = Path(file_path)
    text = path.read_text(encoding="utf-8")
    resolved_title = chapter_title or path.stem
    return ingest_chapter_text(
        text,
        chapter_title=resolved_title,
        service=service,
        sync_mem0=sync_mem0,
        mem0_user_id=mem0_user_id,
    )
