# 技能安装说明

把 `skill/` 整个目录复制到使用者的 Codex 技能目录，并命名为：

```text
qimao-novel-writing
```

常见目标路径：

```text
~/.codex/skills/qimao-novel-writing
```

复制完成后，重启 Codex 或开启新对话即可。

技能主文件：

```text
skill/SKILL.md
```

如果想检查技能元数据是否在，可以看：

```text
skill/agents/openai.yaml
```
