#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
TOOL_DIR="$(cd "${SCRIPT_DIR}/../memory-toolkit" && pwd)"

cd "${TOOL_DIR}"

python3 -m venv .venv
source .venv/bin/activate
python3 -m pip install -U pip
python3 -m pip install -e .

echo
echo "安装完成。"
echo "使用前先执行：source ${TOOL_DIR}/.venv/bin/activate"
echo "然后可运行：novel-memory init"
